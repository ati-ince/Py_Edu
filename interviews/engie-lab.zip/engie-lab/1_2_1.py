# folloowing output

def change(elements):
    elements[0] = 888
    elements = [-3, -1, -2, -3, -4]
    print(elements[0])

numbers = [1, 4, 5]
print(numbers[0])
change(numbers)
print(numbers[0])

#answer 
'''
1
-3
888
'''
# 1 min spend


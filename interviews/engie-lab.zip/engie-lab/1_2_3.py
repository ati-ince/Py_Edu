#result 

a = [[1], [2], [3]]
b = a[-2:]
for i in b:
    i *= 2
print('a={}'.format(a))
print('b={}'.format(b))

#answer
'''
#a 1 2 3
#b 2 3 

#b 2 2 3 3 
#a 1 2 2 3 3 

a=[[1], [2, 2], [3, 3]]
b=[[2, 2], [3, 3]]
'''
# 1 min spend

